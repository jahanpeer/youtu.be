# Dynamic YouTube deep link generator

You can easily add your youtube link at the end of this url : `http://hpdev.ir?u=` and put it in your social medias like instagram **bio** link.

When user click on it on their mobile, this link identify of device OS such as android or ios and open youtube video on official youtube app.

Also if user dont have youtube app or have another OS or open it in desktop, it will use fallback url that is your original video link.

Finally this will help you to your audience open your youtube links in app and use its benefits like that user is alreay signed in and can like or subscribe to your channel.



